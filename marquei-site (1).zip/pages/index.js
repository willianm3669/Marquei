
export default function Home() {
  return (
    <div style={{ padding: 40, fontFamily: 'Arial' }}>
      <h1>Marquei 💈</h1>
      <p>Plataforma de agendamento para barbearias 100% online.</p>
      <p>Seja bem-vindo à versão de testes!</p>
    </div>
  );
}
